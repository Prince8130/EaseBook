<div class="col-sm-12">
					
	<div class="header">
	
		<div class="col-sm-4">
	
		<div class="logo"></div>
		
	</div>
	
		<div class="col-sm-8">
	
		<div class="headerMenu">
			
			<ul>
				<a href="index.php"><li>Home</li></a>
				<li class="active">About Us</li>
				<a href="login.php"><li>Login</li></a>
				<a href="contactUs.php"><li>Contact Us</li></a>
			</ul>
			
		</div>
	</div>
	
	</div> <!-- header -->
				
</div> <!-- col-sm-12 MENU -->